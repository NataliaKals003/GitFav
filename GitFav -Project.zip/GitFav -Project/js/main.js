import { FavoritesView } from "./favorites.js"

new FavoritesView("#app");

